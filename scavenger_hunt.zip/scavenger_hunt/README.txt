Welcome to the Terminal Scavenger Hunt!
Clue for Level 1: Change directory into 'archive' and view the welcome file.
